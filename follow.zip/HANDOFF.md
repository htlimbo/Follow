# FollowMind — Design Handoff for Claude Code

This package contains the UI redesign for FollowMind (原 Follow 项目). Below are instructions to hand this off to Claude Code so it can apply the redesign to your codebase.

---

## What's in this project

| File | Purpose |
|---|---|
| `Portfolio Journal.html` | Main entry — a design canvas showing 3 theme variations for the Overview page, 2 for Stock Detail, and 1 Modal |
| `FollowMind Logo.html` | Logo exploration — 6 marks, wordmark in light/dark, app icon, favicons, brand color tokens |
| `styles.css` | Full design system (3 themes: Warm Paper / Midnight Journal / Kraft Card) |
| `data.jsx` | Sample data matching your current stock structure |
| `icons.jsx` | Icon set + Sparkline + Donut chart components |
| `app.jsx` | React components: Rail, PortfolioList, Overview, StockDetail, Timeline, AddStockModal |

---

## Recommended direction (defaults)

- **Theme:** `Warm Paper` — 暖奶油底色 + 衬线标题 + 柔和色调
- **Logo:** `Arc Dot (02)` — 一条弧线 + 两点，简洁可识别
- **Typography:** Noto Serif SC (衬线) + Noto Sans SC (UI) + JetBrains Mono (数字)
- **Accent color:** Terracotta `oklch(0.58 0.14 38)`
- **Gain/Loss:** 柔和 sage `oklch(0.55 0.10 155)` / dusty rose `oklch(0.58 0.13 25)`（非正红正绿）

---

## How to hand this off to Claude Code

### Step 1 — Download this project

Click the **三点菜单 → Download project as zip** (or use the download card at the bottom of this chat). 解压后会得到一个文件夹，包含以上所有文件。

### Step 2 — Put it next to your Follow repo

```
~/code/
├── Follow/                    ← 你的原项目（从 GitHub clone 的）
└── followmind-redesign/       ← 本次下载的设计稿
```

### Step 3 — 在 Follow 目录下打开 Claude Code

```bash
cd ~/code/Follow
claude
```

### Step 4 — 粘贴下面这段 prompt 给 Claude Code

> 我把新的 UI 设计稿放在了 `../followmind-redesign/` 目录下。请帮我做下面几件事：
>
> 1. **先读文档**：先通读 `../followmind-redesign/HANDOFF.md`（本文件）和 `../followmind-redesign/styles.css` 的前 80 行（CSS 变量 / 三套主题），理解设计系统。然后浏览 `app.jsx` 的组件结构。
>
> 2. **对照当前代码**：运行 `ls src/` 或 `ls app/`，告诉我你观察到的组件目录结构，先不要修改。
>
> 3. **制定迁移计划**：基于我当前的技术栈（请自己检查 package.json），提出一个分阶段的迁移计划：
>    - 阶段 1：引入设计 tokens（把 `styles.css` 里的 CSS 变量迁移到我项目的 theme/tokens 文件）
>    - 阶段 2：替换 Logo（使用 Arc Dot 方案，从 `FollowMind Logo.html` 的 SVG 复制）
>    - 阶段 3：重构 Portfolio List 列表项样式（参考 `app.jsx` 里的 `StockItem`）
>    - 阶段 4：重构 Overview 页（参考 `Overview` 组件）
>    - 阶段 5：重构 Stock Detail + Timeline（参考 `StockDetail` + `Timeline`）
>    - 阶段 6：重构 Add Stock Modal
>
> 4. **等我确认后再动手**。每个阶段完成后给我看 diff，确认后再进下一个。
>
> 5. **保持数据层不动**：我只需要 UI 改造，数据获取 / 状态管理逻辑保持原样。
>
> 重要约束：
> - 用 Noto Serif SC + Noto Sans SC，不要 Inter
> - 涨跌用柔和色，不要正红正绿
> - 不要引入新依赖，只改样式和组件结构
> - 默认主题是 Warm Paper，但需要支持切主题

### Step 5 — 渐进式迁移

Claude Code 会分阶段提交，你可以每阶段 review、测试、再继续。强烈建议先在新分支上做：

```bash
git checkout -b redesign/followmind-ui
```

---

## Logo 资源导出

Logo 推荐方案（Arc Dot）的 SVG 源码：

**图标版（方形载体，用于 App icon / favicon）**
```svg
<svg width="32" height="32" viewBox="0 0 32 32">
  <rect width="32" height="32" rx="6" fill="oklch(0.25 0.025 60)"/>
  <path d="M4 24 C 12 24, 17 14, 26 9"
        fill="none" stroke="oklch(0.98 0.012 80)"
        stroke-width="2.6" stroke-linecap="round"/>
  <circle cx="26" cy="9" r="3.5" fill="oklch(0.72 0.14 50)"/>
</svg>
```

**标志版（无载体，用于 header / 文档）**
```svg
<svg width="48" height="48" viewBox="0 0 48 48">
  <path d="M6 36 C 18 36, 26 22, 40 14"
        fill="none" stroke="oklch(0.25 0.025 60)"
        stroke-width="3.5" stroke-linecap="round"/>
  <circle cx="40" cy="14" r="5" fill="oklch(0.58 0.14 38)"/>
  <circle cx="6" cy="36" r="2.5" fill="oklch(0.25 0.025 60)"/>
</svg>
```

如需 PNG，可在浏览器里打开 `FollowMind Logo.html`，右键 SVG → Save image as。或让 Claude Code 帮你生成多尺寸 PNG / ICO。

---

## Domain suggestion

`followmind.app` / `followmind.io` / `followmind.cn` — 任选。`.app` 有强制 HTTPS 加成、对工具类产品识别度高。

---

有问题回来继续问我，我可以帮你调整单个页面或追加新的界面。
