/* Portfolio Journal — sample data */

const STOCKS = [
  {
    id: 'tencent', name: '腾讯控股', code: '00700', status: 'watch',
    price: '—', delta: null, pct: null, days: null, spark: 'flat',
    note: null, active: false,
  },
  {
    id: 'sf', name: '顺丰控股', code: '002352', status: 'hold',
    price: 36.65, delta: -1.46, pct: -28.32, days: 9, spark: 'down',
    note: null,
  },
  {
    id: 'popmart', name: '泡泡玛特', code: '09992', status: 'hold',
    price: 166.90, delta: 29.40, pct: 0.09, days: 9, spark: 'upflat',
    note: null,
  },
  {
    id: 'meituan', name: '美团-W', code: '03690', status: 'hold',
    price: 94.25, delta: -1.56, pct: -38.58, days: 9, spark: 'down',
    note: null,
  },
  {
    id: 'xindong', name: '心动公司', code: '03400', status: 'hold',
    price: 62.45, delta: -1.63, pct: -14.04, days: 12, spark: 'downrec',
    note: null,
  },
  {
    id: 'catl', name: '宁德时代', code: '300750', status: 'watch',
    price: '—', delta: null, pct: null, days: null, spark: 'flat',
    note: null,
  },
  {
    id: 'chinamobile', name: '中国移动', code: '600941', status: 'hold',
    price: 96.15, delta: 601.80, pct: 3.23, days: 9, spark: 'up',
    note: null,
  },
  {
    id: 'ganfeng', name: '赣锋锂业', code: '002460', status: 'hold',
    price: 79.93, delta: 12.31, pct: 240.53, days: 12, spark: 'rocket',
    note: '情绪估值似乎已见顶。',
  },
  {
    id: 'huaxin', name: '华新建材', code: '06655', status: 'hold',
    price: 16.98, delta: 1040.40, pct: 3.74, days: 9, spark: 'upslow',
    note: null,
  },
];

const ALLOCATION = [
  { name: '中国移动', pct: 5.6, color: 'var(--violet)' },
  { name: '美团-W', pct: 7.2, color: 'var(--loss)' },
  { name: '华新建材', pct: 8.4, color: 'var(--gold)' },
  { name: '泡泡玛特', pct: 9.1, color: 'var(--sky)' },
  { name: '顺丰控股', pct: 10.8, color: 'var(--gain)' },
  { name: '心动公司', pct: 29.2, color: 'var(--accent)' },
  { name: '赣锋锂业', pct: 21.0, color: 'oklch(0.55 0.12 280)' },
  { name: '现金', pct: 8.8, color: 'var(--ink-faint)' },
];

// PnL by position (万元)
const PNL_BARS = [
  { name: '赣锋锂业', val: 12.30, pct: '+240.53%' },
  { name: '华新建材', val: 1.04, pct: '+3.74%' },
  { name: '中国移动', val: 0.60, pct: '+3.23%' },
  { name: '泡泡玛特', val: 0.29, pct: '+0.09%' },
  { name: '顺丰控股', val: -1.46, pct: '-28.32%' },
  { name: '美团-W', val: -1.56, pct: '-38.58%' },
  { name: '心动公司', val: -1.63, pct: '-14.04%' },
];

const TIMELINE = [
  {
    id: 1, kind: '思考', ago: '3天前',
    body: '情绪估值似乎已见顶。',
    tag: '情绪顶点',
  },
  {
    id: 2, kind: '思考', date: '2026年4月14日 16:04',
    body: '下一个关键时点：2026Q1 季报（预计 4 月底），验证碳酸锂 15 万/吨下主营盈利能力。这是从"周期反转假设"到"周期反转确认"的关键一跳。',
  },
  {
    id: 3, kind: '思考', date: '2026年4月14日 16:04',
    body: '如碳酸锂冲破 18 万/吨可考虑再减 100-200 股锁定利润。成本在 -56.87 万元，无论如何这笔投资已经是大赢——现在的任务是保护利润而不是赢得更多。',
  },
];

Object.assign(window, { STOCKS, ALLOCATION, PNL_BARS, TIMELINE });
