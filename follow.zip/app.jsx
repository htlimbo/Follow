/* Portfolio Journal — shell components */

const { useState, useMemo } = React;

function Rail({ onShowModal }) {
  return (
    <aside className="pj-rail">
      <div className="pj-rail-brand" title="FollowMind">
        <svg width="22" height="22" viewBox="0 0 32 32">
          <path d="M4 24 C 12 24, 17 14, 26 9" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round"/>
          <circle cx="26" cy="9" r="3.5" fill="var(--accent)"/>
          <circle cx="4" cy="24" r="1.6" fill="currentColor"/>
        </svg>
      </div>
      <div className="pj-rail-nav">
        <button className="pj-rail-btn active" title="持仓"><I.Trend/></button>
        <button className="pj-rail-btn" title="组合"><I.Portfolio/></button>
        <button className="pj-rail-btn" title="日志"><I.Journal/></button>
      </div>
      <div className="pj-rail-foot">
        <button className="pj-rail-btn" title="设置"><I.Settings/></button>
        <button className="pj-rail-btn" title="退出"><I.Logout/></button>
      </div>
    </aside>
  );
}

function StockItem({ stock, active, onClick }) {
  const isNeutral = stock.pct === null;
  const pctClass = isNeutral ? 'neutral' : (stock.pct >= 0 ? 'gain' : 'loss');
  const deltaClass = isNeutral ? '' : (stock.delta >= 0 ? 'gain' : 'loss');
  const pctText = isNeutral ? '—' : `${stock.pct >= 0 ? '+' : ''}${stock.pct.toFixed(2)}%`;
  return (
    <div className={`pj-stock ${active ? 'active' : ''}`} onClick={onClick}>
      <div className="pj-stock-row1">
        <div className="pj-stock-name serif">
          <span>{stock.name}</span>
          <span className={`pj-stock-tag ${stock.status}`}>
            {stock.status === 'watch' ? '观察' : stock.status === 'hold' ? '持仓' : '已清仓'}
          </span>
        </div>
        <span className={`pj-stock-pct ${pctClass}`}>{pctText}</span>
      </div>
      <div className="pj-stock-row2">
        <span className="pj-stock-code">{stock.code}</span>
        {!isNeutral && (
          <>
            <span className="pj-stock-price">{typeof stock.price === 'number' ? stock.price.toFixed(2) : stock.price}</span>
            <span className={`pj-stock-delta ${deltaClass}`}>{stock.delta >= 0 ? '+' : ''}{stock.delta.toFixed(2)}</span>
          </>
        )}
        {stock.days && <span className="pj-stock-days">持仓 {stock.days} 天</span>}
      </div>
      {!isNeutral && (
        <div className="pj-stock-spark">
          <Sparkline kind={stock.spark}/>
        </div>
      )}
      {stock.note && (
        <div className="pj-stock-note">"{stock.note}"</div>
      )}
    </div>
  );
}

function PortfolioList({ activeId, onSelect, onAdd, activeTab, setActiveTab }) {
  const tabs = [
    { id: 'all', label: '全部', filter: () => true },
    { id: 'hold', label: '持仓', filter: s => s.status === 'hold' },
    { id: 'watch', label: '观察', filter: s => s.status === 'watch' },
    { id: 'cleared', label: '已清仓', filter: s => s.status === 'cleared' },
  ];
  const currentFilter = tabs.find(t => t.id === activeTab)?.filter || (() => true);
  const filtered = STOCKS.filter(currentFilter);
  return (
    <section className="pj-list">
      <div className="pj-list-head">
        <div className="pj-list-title-row">
          <div>
            <div className="pj-list-sub">My Portfolio</div>
            <h2 className="pj-list-title">组合总览</h2>
          </div>
          <button className="pj-add-btn" onClick={onAdd}>
            <I.Plus/> 添加
          </button>
        </div>
        <div className="pj-tabs">
          {tabs.map(t => {
            const count = STOCKS.filter(t.filter).length;
            return (
              <button
                key={t.id}
                className={`pj-tab ${activeTab === t.id ? 'active' : ''}`}
                onClick={() => setActiveTab(t.id)}
              >
                {t.label}<span className="count">{count}</span>
              </button>
            );
          })}
        </div>
        <div className="pj-list-filters">
          <span className="pj-sort">
            <I.Chevron style={{width: 12, height: 12}}/> 最近活跃
          </span>
          <span className="pj-list-icons">
            <button className="pj-icon-btn" title="刷新"><I.Refresh/></button>
            <button className="pj-icon-btn" title="导出"><I.Download/></button>
            <button className="pj-icon-btn" title="导入"><I.Upload/></button>
          </span>
        </div>
      </div>
      <div className="pj-list-body">
        {filtered.map(s => (
          <StockItem key={s.id} stock={s} active={s.id === activeId} onClick={() => onSelect(s.id)} />
        ))}
      </div>
    </section>
  );
}

/* ======================= Overview ======================= */
function Overview() {
  return (
    <main className="pj-main">
      <div className="pj-main-inner">
        <div className="pj-overview-head">
          <div className="pj-overview-eyebrow">Portfolio · 统计</div>
          <h1 className="pj-overview-title">组合统计</h1>
          <div className="pj-overview-date">截至 2026年4月23日 · 7 只持仓 · 更新于 2 分钟前</div>
        </div>

        <div className="pj-cash-row">
          <div>
            <div className="pj-cash-label">现金仓位</div>
          </div>
          <div>
            <span className="pj-cash-value">30,000</span>
            <span className="pj-cash-unit">元</span>
          </div>
        </div>

        <div className="pj-stat-grid">
          <div className="pj-stat">
            <div className="pj-stat-label">持仓数</div>
            <div className="pj-stat-val">7</div>
            <div className="pj-stat-sub">2 只观察中</div>
          </div>
          <div className="pj-stat">
            <div className="pj-stat-label">总资产</div>
            <div className="pj-stat-val">34.27<span style={{fontSize:'16px', color:'var(--ink-faint)'}}>万</span></div>
            <div className="pj-stat-sub">持仓 31.27万 · 现金 3万</div>
          </div>
          <div className="pj-stat">
            <div className="pj-stat-label">总盈亏</div>
            <div className="pj-stat-val gain">+7.83<span style={{fontSize:'16px'}}>万</span></div>
            <div className="pj-stat-sub gain">+33.41% 全周期</div>
          </div>
        </div>

        <section className="pj-card">
          <div className="pj-card-head">
            <div className="pj-card-title">持仓分布</div>
            <div className="pj-card-sub">按市值占比</div>
          </div>
          <div className="pj-donut-wrap">
            <Donut data={ALLOCATION}/>
            <div className="pj-donut-legend">
              {ALLOCATION.map(a => (
                <div className="pj-legend-item" key={a.name}>
                  <span className="pj-legend-dot" style={{background: a.color}}/>
                  <span className="pj-legend-name">{a.name}</span>
                  <span className="pj-legend-pct">{a.pct}%</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="pj-card">
          <div className="pj-card-head">
            <div className="pj-card-title">个股盈亏金额</div>
            <div className="pj-card-sub">单位：万元</div>
          </div>
          <div className="pj-bars">
            {PNL_BARS.map(b => {
              const max = 13;
              const isGain = b.val >= 0;
              const widthPct = (Math.abs(b.val) / max) * 50; // each half = 50%
              return (
                <div className="pj-bar-row" key={b.name}>
                  <div className="pj-bar-name">{b.name}</div>
                  <div className="pj-bar-track">
                    <div className="pj-bar-axis"/>
                    {isGain ? (
                      <div
                        className="pj-bar-fill gain"
                        style={{ marginLeft: '50%', width: `${widthPct}%` }}
                      />
                    ) : (
                      <div
                        className="pj-bar-fill loss"
                        style={{ marginLeft: `${50 - widthPct}%`, width: `${widthPct}%` }}
                      />
                    )}
                  </div>
                  <div className={`pj-bar-val ${isGain ? 'gain' : 'loss'}`}>
                    {isGain ? '+' : ''}{b.val.toFixed(2)}
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </main>
  );
}

/* ======================= Stock Detail ======================= */
function StockDetail({ stock, onClose }) {
  const isGain = stock.pct >= 0;
  return (
    <section className="pj-detail">
      <div className="pj-detail-inner">
        <div className="pj-detail-head">
          <div>
            <h2 className="pj-detail-title">{stock.name}</h2>
            <div className="pj-detail-code">{stock.code} · 深交所 · SHE</div>
          </div>
          <button className="pj-icon-btn" title="删除" onClick={onClose}><I.Trash/></button>
        </div>

        <div className="pj-detail-stats">
          <div className="pj-detail-stat">
            <div className="pj-dstat-label">成本价</div>
            <div className="pj-dstat-val">56.878</div>
          </div>
          <div className="pj-detail-stat">
            <div className="pj-dstat-label">现价</div>
            <div className="pj-dstat-val">
              79.93
              <span className={`pj-dstat-pct ${isGain ? 'gain' : 'loss'}`}>+240.53%</span>
            </div>
          </div>
          <div className="pj-detail-stat">
            <div className="pj-dstat-label">持仓数量</div>
            <div className="pj-dstat-val">900 <span style={{fontSize:12, color:'var(--ink-faint)'}}>股</span></div>
          </div>
        </div>

        <div className={`pj-pnl-callout ${isGain ? '' : 'loss'}`}>
          <div className="pj-pnl-group">
            <div className="pj-pnl-label">盈亏金额</div>
            <div className={`pj-pnl-val ${isGain ? 'gain' : 'loss'}`}>+12.31 <span style={{fontSize:13, opacity:.7}}>万</span></div>
          </div>
          <div style={{flex: 1, height: 38}}>
            <Sparkline kind="rocket"/>
          </div>
          <div className="pj-pnl-group" style={{textAlign:'right'}}>
            <div className="pj-pnl-label">持仓市值</div>
            <div className="pj-pnl-val">7.19 <span style={{fontSize:13, opacity:.7}}>万</span></div>
          </div>
        </div>

        <div className="pj-section-label">
          研究摘要 <span className="ico-btn"><I.Edit/></span>
        </div>
        <div className="pj-thesis">
          <span className="drop">第</span>三轮碳酸锂上行周期启动 × 量价齐升（锂盐 18.5 万/吨 +42%、锂价从 7万 → 15万）× 储能电池出货第二增长曲线（出货 +117%）× 固态电池产业链卡位。产业库存压降至不足一个月用量，12 万/吨形成坚实底。
        </div>

        <div className="pj-section-label">看多 & 风险</div>
        <div className="pj-pro-con-grid">
          <div className="pj-pro-con pro">
            <div className="pj-pro-con-head"><I.Check style={{width:12, height:12}}/> 看好理由</div>
            <ol>
              <li>供给收缩验证：前 2-3 年碳酸锂暴跌击穿万元级成本线</li>
              <li>需求双轮驱动：2025 年车销 1,649 万辆（+28%），电池蓄出货 630GWh</li>
              <li>锂价自身量增锁定：2025 年锂盐 18.5 万/吨（+42%）</li>
              <li>固态电池卡位：全球第一固态电池上游</li>
            </ol>
          </div>
          <div className="pj-pro-con con">
            <div className="pj-pro-con-head"><I.X style={{width:12, height:12}}/> 风险点</div>
            <ol>
              <li>碳酸锂价格回落：当前 15 万/吨已从 6 万涨近 3 倍</li>
              <li>扣非归母：2025 全年扣非 3.85 亿 16.13 元</li>
              <li>估值安全垫收窄：88 亿对应 2026 PE 约 19x（中性）</li>
              <li>固态电池卡位：全球第一固态电池上游，竞争格局未定</li>
            </ol>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ======================= Timeline ======================= */
function Timeline() {
  const [filter, setFilter] = useState('all');
  return (
    <section className="pj-timeline">
      <div className="pj-timeline-head">
        <div>
          <div className="pj-list-sub">Think Journal</div>
          <div className="pj-timeline-title">思考时间线</div>
        </div>
        <button className="pj-timeline-add"><I.Plus2 style={{width:12, height:12}}/> 记录想法</button>
      </div>
      <div className="pj-timeline-filter">
        <button className={filter === 'all' ? 'active' : ''} onClick={() => setFilter('all')}>全部<span className="count">3</span></button>
        <button className={filter === 'thought' ? 'active' : ''} onClick={() => setFilter('thought')}>思考<span className="count">3</span></button>
        <button className={filter === 'trade' ? 'active' : ''} onClick={() => setFilter('trade')}>交易<span className="count">0</span></button>
      </div>
      <div className="pj-timeline-items">
        {TIMELINE.map(e => (
          <div className="pj-entry thought" key={e.id}>
            <div className="pj-entry-meta">
              <span className="pj-entry-kind">{e.kind}</span>
              {e.ago && <span className="pj-entry-ago">{e.ago}</span>}
              {e.date && <span className="pj-entry-date">{e.date}</span>}
            </div>
            <div className="pj-entry-body">{e.body}</div>
            {e.tag && <span className="pj-entry-tag">#{e.tag}</span>}
          </div>
        ))}
      </div>
    </section>
  );
}

/* ======================= Add Stock Modal ======================= */
function AddStockModal({ onClose }) {
  const [q, setQ] = useState('');
  const [selected, setSelected] = useState('300750');
  const [kind, setKind] = useState('watch');
  const results = [
    { name: '宁德时代', code: '300750', meta: 'SZ · ￥285.4' },
    { name: '比亚迪', code: '002594', meta: 'SZ · ￥268.9' },
    { name: '腾讯控股', code: '00700', meta: 'HK · HK$ 412' },
  ].filter(r => !q || r.name.includes(q) || r.code.includes(q));
  return (
    <div className="pj-modal-backdrop" onClick={onClose}>
      <div className="pj-modal" onClick={e => e.stopPropagation()}>
        <div className="pj-modal-head">
          <div className="pj-modal-title">添加到组合</div>
          <div className="pj-modal-sub">先记录观察，买入后再转为持仓 —— 记录每一次决策。</div>
        </div>
        <div className="pj-modal-body">
          <div className="pj-field">
            <div className="pj-field-label">股票代码 / 名称</div>
            <input className="pj-input" placeholder="搜索 002460 或 赣锋锂业…" value={q} onChange={e => setQ(e.target.value)}/>
            <div className="pj-search-results">
              {results.map(r => (
                <div
                  key={r.code}
                  className={`pj-search-item ${r.code === selected ? 'selected' : ''}`}
                  onClick={() => setSelected(r.code)}
                >
                  <div>
                    <span className="pj-search-name serif">{r.name}</span>
                    <span className="pj-search-code">{r.code}</span>
                  </div>
                  <div className="pj-search-meta">{r.meta}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="pj-field">
            <div className="pj-field-label">加入方式</div>
            <div className="pj-kind-choice">
              <button className={`pj-kind-btn ${kind === 'watch' ? 'active' : ''}`} onClick={() => setKind('watch')}>
                <div className="pj-kind-btn-title">仅观察</div>
                <div className="pj-kind-btn-sub">追踪价格变化，尚未买入</div>
              </button>
              <button className={`pj-kind-btn ${kind === 'hold' ? 'active' : ''}`} onClick={() => setKind('hold')}>
                <div className="pj-kind-btn-title">已持仓</div>
                <div className="pj-kind-btn-sub">填写成本价与数量</div>
              </button>
            </div>
          </div>
          {kind === 'hold' && (
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12}}>
              <div className="pj-field">
                <div className="pj-field-label">成本价</div>
                <input className="pj-input" placeholder="0.00"/>
              </div>
              <div className="pj-field">
                <div className="pj-field-label">持仓数量</div>
                <input className="pj-input" placeholder="0"/>
              </div>
            </div>
          )}
        </div>
        <div className="pj-modal-foot">
          <button className="pj-btn-ghost" onClick={onClose}>取消</button>
          <button className="pj-btn-primary" onClick={onClose}>添加</button>
        </div>
      </div>
    </div>
  );
}

/* ======================= App shell ======================= */
function App({ view = 'overview', theme = 'paper' }) {
  const [activeId, setActiveId] = useState(view === 'detail' ? 'ganfeng' : null);
  const [tab, setTab] = useState('all');
  const [modal, setModal] = useState(view === 'modal');
  const activeStock = useMemo(() => STOCKS.find(s => s.id === activeId), [activeId]);
  const showDetail = activeStock && activeStock.status !== 'cleared';

  return (
    <div className={`pj-app theme-${theme}`} style={{width:'100%', height:'100%'}}>
      <div className={`pj-shell ${showDetail ? 'with-detail' : ''}`}>
        <Rail onShowModal={() => setModal(true)}/>
        <PortfolioList
          activeId={activeId}
          onSelect={setActiveId}
          onAdd={() => setModal(true)}
          activeTab={tab}
          setActiveTab={setTab}
        />
        {showDetail ? (
          <>
            <StockDetail stock={activeStock} onClose={() => setActiveId(null)}/>
            <Timeline/>
          </>
        ) : (
          <Overview/>
        )}
        {modal && <AddStockModal onClose={() => setModal(false)}/>}
      </div>
    </div>
  );
}

Object.assign(window, { App, Rail, PortfolioList, Overview, StockDetail, Timeline, AddStockModal });
