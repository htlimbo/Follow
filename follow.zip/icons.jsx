/* Portfolio Journal — icons + small viz */

const I = {
  Trend: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 17l6-6 4 4 8-8"/><path d="M17 7h4v4"/></svg>,
  Portfolio: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="6" width="18" height="14" rx="2"/><path d="M8 6V4h8v2"/></svg>,
  Journal: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>,
  Settings: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>,
  Logout: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>,
  Plus: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  Chevron: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6"/></svg>,
  Refresh: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/></svg>,
  Download: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 3v12M6 9l6 6 6-6"/><path d="M5 21h14"/></svg>,
  Upload: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 21V9M6 15l6-6 6 6"/><path d="M5 3h14"/></svg>,
  Trash: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M4 7h16M10 11v6M14 11v6"/><path d="M5 7l1 13a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2l1-13"/><path d="M9 7V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3"/></svg>,
  Edit: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>,
  ChevronUp: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M18 15l-6-6-6 6"/></svg>,
  Plus2: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>,
  Check: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5"/></svg>,
  X: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>,
  Spark: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l1.7 4.4L18 8l-4.3 1.6L12 14l-1.7-4.4L6 8l4.3-1.6z"/></svg>,
  Think: (p) => <svg {...p} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="5"/><path d="M8 18h8M10 21h4"/></svg>,
};

/* ---- Sparklines ---- */
function Sparkline({ kind = 'flat', color }) {
  const paths = {
    up:      'M0 22 C15 20, 30 18, 45 16 S 75 8, 100 6 S 140 10, 170 8 S 210 4, 240 2',
    upslow:  'M0 20 C20 18, 40 17, 60 16 S 100 12, 140 11 S 180 9, 240 8',
    upflat:  'M0 18 C20 16, 50 14, 80 15 S 120 12, 160 12 S 200 10, 240 11',
    down:    'M0 6 C20 8, 40 10, 60 11 S 110 16, 140 18 S 190 22, 240 23',
    downrec: 'M0 8 C30 11, 60 18, 90 20 S 130 22, 160 16 S 200 10, 240 12',
    flat:    'M0 14 C30 14, 60 13, 90 14 S 150 14, 180 14 S 220 14, 240 14',
    rocket:  'M0 24 C20 23, 50 22, 80 20 S 130 14, 170 8 S 210 2, 240 1',
  };
  const isUp = /up|rocket/.test(kind);
  const isDown = /^down/.test(kind);
  const stroke = color || (isUp ? 'var(--gain)' : isDown ? 'var(--loss)' : 'var(--ink-faint)');
  const fill = isUp ? 'var(--gain-soft)' : isDown ? 'var(--loss-soft)' : 'transparent';
  const path = paths[kind] || paths.flat;
  return (
    <svg viewBox="0 0 240 26" preserveAspectRatio="none">
      <defs>
        <linearGradient id={`spk-${kind}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={isUp ? 'var(--gain)' : isDown ? 'var(--loss)' : 'var(--ink-faint)'} stopOpacity="0.25"/>
          <stop offset="100%" stopColor={isUp ? 'var(--gain)' : isDown ? 'var(--loss)' : 'var(--ink-faint)'} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <path d={`${path} L 240 26 L 0 26 Z`} fill={`url(#spk-${kind})`} />
      <path d={path} fill="none" stroke={stroke} strokeWidth="1.25" strokeLinecap="round" />
    </svg>
  );
}

/* ---- Donut chart ---- */
function Donut({ data, size = 180 }) {
  const r = size / 2;
  const strokeW = 28;
  const innerR = r - strokeW / 2;
  const circumference = 2 * Math.PI * innerR;
  let offset = 0;
  const total = data.reduce((s, d) => s + d.pct, 0);
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <g transform={`translate(${r}, ${r}) rotate(-90)`}>
        {data.map((d, i) => {
          const len = (d.pct / total) * circumference;
          const seg = (
            <circle
              key={i}
              r={innerR}
              fill="none"
              stroke={d.color}
              strokeWidth={strokeW}
              strokeDasharray={`${len} ${circumference - len}`}
              strokeDashoffset={-offset}
              opacity={0.92}
            />
          );
          offset += len + 1.5; // tiny gap
          return seg;
        })}
      </g>
      <text x={r} y={r - 4} textAnchor="middle" fontFamily="var(--serif)" fontSize="12" fill="var(--ink-faint)" letterSpacing="0.05em">持仓分布</text>
      <text x={r} y={r + 14} textAnchor="middle" fontFamily="var(--mono)" fontSize="16" fontWeight="500" fill="var(--ink)">31.27万</text>
    </svg>
  );
}

Object.assign(window, { I, Sparkline, Donut });
